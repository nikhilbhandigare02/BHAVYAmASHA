part of 'all_household_bloc.dart';

@immutable
sealed class AllHouseholdEvent {}
