part of 'training_provided_bloc.dart';

@immutable
sealed class TrainingProvidedEvent {}
