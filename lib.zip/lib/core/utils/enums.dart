enum PostApiStatus {initial, loading, success, error}

enum Status {loading, complete, error}
enum FormStatus { initial, valid, submitting, success, failure }
enum GbsStatus { initial, submitting, success, failure, loading }
