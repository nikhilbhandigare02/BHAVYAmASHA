class BaseUrls {
  static const String baseUrl = 'https://maasha-app-uat-server.medixcel.in';
  // Add other environment URLs if needed
  // static const String stagingUrl = 'https://staging.your-api-base-url.com/api';
  // static const String productionUrl = 'https://prod.your-api-base-url.com/api';
}