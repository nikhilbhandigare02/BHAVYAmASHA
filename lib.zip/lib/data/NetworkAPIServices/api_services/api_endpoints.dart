class ApiEndpoints {
    static const String baseAbdmUrl = 'https://abdm-central-uat.medixcel.in/v3/'; //UAT
    // static const String baseAbdmUrl = 'https://ndhm-central.medixcel.in/v3/';  //LIve
    //static const String baseUrl = 'https://yw4x45z1n2.execute-api.us-west-2.amazonaws.com';
    static const String baseUrl = 'https://lq8nkxmu90.execute-api.ap-south-1.amazonaws.com';

}
