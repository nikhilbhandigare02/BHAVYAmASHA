part of 'all_beneficiary_bloc.dart';

@immutable
sealed class AllBeneficiaryEvent {}
