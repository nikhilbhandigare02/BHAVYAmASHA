part of 'all_household_bloc.dart';

@immutable
sealed class AllHouseholdState {}

final class AllHouseholdInitial extends AllHouseholdState {}
