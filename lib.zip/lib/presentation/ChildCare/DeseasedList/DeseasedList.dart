import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:medixcel_new/core/widgets/AppHeader/AppHeader.dart';
import 'package:medixcel_new/data/Database/local_storage_dao.dart';
import 'package:medixcel_new/data/Database/tables/followup_form_data_table.dart';
import 'package:medixcel_new/l10n/app_localizations.dart';
import 'package:sizer/sizer.dart';
import '../../../core/config/themes/CustomColors.dart';
import '../../../data/Database/database_provider.dart';
import '../../../data/Database/tables/beneficiaries_table.dart';
import '../../../data/SecureStorage/SecureStorage.dart';

class DeseasedList extends StatefulWidget {
  const DeseasedList({super.key});

  @override
  State<DeseasedList> createState() => _DeseasedListState();
}

class _DeseasedListState extends State<DeseasedList> {
  final TextEditingController _searchCtrl = TextEditingController();
  final LocalStorageDao _storageDao = LocalStorageDao();

  bool _isLoading = true;
  List<Map<String, dynamic>> _deceasedList = [];
  List<Map<String, dynamic>> _filtered = [];

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearchChanged);
    _loadDeceasedList();
  }

  Future<void> _loadDeceasedList() async {
    try {
      setState(() {
        _isLoading = true;
      });

      final db = await DatabaseProvider.instance.database;

      // Get current user's unique key
      final currentUserData = await SecureStorageService.getCurrentUserData();
      final String? ashaUniqueKey = currentUserData?['unique_key']?.toString();

      // Query to get deceased beneficiaries with their details
      final List<Map<String, dynamic>> deceasedBeneficiaries = await db.rawQuery('''
      SELECT 
        b.*,
        h.household_info as household_data,
        h.created_date_time as household_created_date,
        h.household_info as hh_info
      FROM ${BeneficiariesTable.table} b
      LEFT JOIN households h ON b.household_ref_key = h.unique_key
      WHERE b.is_death = 1 ${ashaUniqueKey != null && ashaUniqueKey.isNotEmpty ? 'AND b.current_user_key = ?' : ''}
      ORDER BY b.created_date_time DESC
    ''', ashaUniqueKey != null && ashaUniqueKey.isNotEmpty ? [ashaUniqueKey] : []);

      final transformed = deceasedBeneficiaries.map((beneficiary) {
        // Parse JSON data
        final beneficiaryInfo = jsonDecode(beneficiary['beneficiary_info']?.toString() ?? '{}');
        final householdData = jsonDecode(beneficiary['hh_info']?.toString() ?? '{}');
        final deathDetails = jsonDecode(beneficiary['death_details']?.toString() ?? '{}');

        // Helper function to safely get values
        String getValue(dynamic value, [String defaultValue = 'N/A']) {
          if (value == null ||
              (value is String && value.trim().isEmpty) ||
              value == 'null') {
            return defaultValue;
          }
          return value.toString();
        }

        // Format date
        String formatDate(dynamic dateValue, [String defaultValue = 'N/A']) {
          if (dateValue == null) return defaultValue;
          try {
            final dateString = dateValue.toString();
            if (dateString.isEmpty) return defaultValue;
            final date = DateTime.parse(dateString);
            return '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}';
          } catch (e) {
            return dateValue.toString();
          }
        }

        // Get registration date (from household creation date or beneficiary creation date)
        final registrationDate = beneficiary['household_created_date'] ??
            beneficiary['created_date_time'];


        String getAge() {
          // First try to get age directly
          if (beneficiaryInfo['years'] != null) {
            return getValue(beneficiaryInfo['years']);
          } else if(beneficiaryInfo['months'] != null) {
            return getValue(beneficiaryInfo['months']);
          } else if(beneficiaryInfo['days'] != null) {
            return getValue(beneficiaryInfo['days']);
          }

          if (beneficiaryInfo['dob'] != null) {
            try {
              final dob = DateTime.parse(beneficiaryInfo['dob']);
              final now = DateTime.now();
              int age = now.year - dob.year;
              if (now.month < dob.month ||
                  (now.month == dob.month && now.day < dob.day)) {
                age--;
              }
              return age > 0 ? age.toString() : 'N/A';
            } catch (e) {
              return 'N/A';
            }
          }
          return 'N/A';
        }

        // Get registration type (from beneficiary type or default to 'Child')
        String getRegistrationType() {
          return getValue(
              beneficiaryInfo['beneficiaryType'] ??
                  (beneficiary['is_adult'] == 1 ? 'Adult' : 'Child')
          );
        }

        // Get father's name - check multiple possible fields
        String getFatherName() {
          return getValue(
              beneficiaryInfo['fatherName'] ??
                  beneficiaryInfo['father_name'] ??
                  beneficiaryInfo['spouseName'] ??
                  householdData['father_name']
          );
        }

        // Get mobile number - check multiple possible fields
        String getMobileNumber() {
          return getValue(
              beneficiaryInfo['mobileNo'] ??
                  beneficiaryInfo['mobile_number'] ??
                  beneficiaryInfo['contact_number'] ??
                  householdData['mobile_number'] ??
                  householdData['contact_number']
          );
        }

        // Get death details
        final causeOfDeath = getValue(
            deathDetails['cause_of_death'] ??
                deathDetails['probable_cause_of_death'] ??
                'Not specified'
        );

        final reason = getValue(
            deathDetails['reason'] ??
                deathDetails['reason_of_death'] ??
                'Not specified'
        );

        final place = getValue(
            deathDetails['place'] ??
                deathDetails['death_place'] ??
                'Not specified'
        );

        final dateOfDeath = formatDate(
            deathDetails['date_of_death'] ??
                deathDetails['death_date']
        );

        return {
          'hhId': getValue(householdData['household_id'] ??
              beneficiary['household_ref_key']),
          'RegitrationDate': formatDate(registrationDate),
          'RegitrationType': getRegistrationType(),
          'BeneficiaryID': getValue(beneficiary['unique_key']),
          'RchID': getValue(beneficiaryInfo['rch_id']),
          'Name': getValue(beneficiaryInfo['name'] ??
              beneficiaryInfo['headName'] ??
              beneficiaryInfo['child_name']),
          'Age|Gender': '${getAge()} | ${getValue(beneficiaryInfo['gender'])}',
          'Mobileno.': getMobileNumber(),
          'FatherName': getFatherName(),
          'MotherName': getValue(
              beneficiaryInfo['mother_name'] ??
                  beneficiaryInfo['motherName']
          ),
          'causeOFDeath': causeOfDeath,
          'reason': reason,
          'place': place,
          'DateofDeath': dateOfDeath,
          'age': getAge(),
          'gender': getValue(beneficiaryInfo['gender']),
          'is_synced': beneficiary['is_synced'],
        };
      }).toList();

      setState(() {
        _deceasedList = transformed;
        _filtered = List<Map<String, dynamic>>.from(_deceasedList);
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading deceased list: $e');
      setState(() {
        _isLoading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load deceased list: $e')),
        );
      }
    }
  }

  String? _formatDate(String? dateString) {
    if (dateString == null) return null;
    try {
      final date = DateTime.parse(dateString);
      return '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}';
    } catch (e) {
      return dateString;
    }
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final q = _searchCtrl.text.trim().toLowerCase();
    setState(() {
      if (q.isEmpty) {
        _filtered = List<Map<String, dynamic>>.from(_deceasedList);
      } else {
        _filtered = _deceasedList.where((e) {
          return (e['hhId']?.toString() ?? '').toLowerCase().contains(q) ||
              (e['Name']?.toString() ?? '').toLowerCase().contains(q) ||
              (e['Mobileno.']?.toString() ?? '').toLowerCase().contains(q) ||
              (e['BeneficiaryID']?.toString() ?? '').toLowerCase().contains(q);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppHeader(
        screenTitle: 'Deceased Child List',
        showBack: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildMainContent(),
    );
  }

  Widget _buildMainContent() {
    return Column(
      children: [
        // Search Box (always visible)
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: _searchCtrl,
            decoration: InputDecoration(
              hintText: 'Search by name, ID, or mobile',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4.0),
              ),
            ),
          ),
        ),

        Expanded(
          child: _filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.search_off,
                        size: 48,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _deceasedList.isEmpty
                            ? 'No deceased children found'
                            : 'No matching records found',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: _filtered.length,
                    itemBuilder: (context, index) {
                      final data = _filtered[index];
                      return _deceasedCard(context, data);
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _deceasedCard(BuildContext context, Map<String, dynamic> data) {
    final l10n = AppLocalizations.of(context);
    final Color primary = Theme.of(context).primaryColor;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.25),
                blurRadius: 2,
                spreadRadius: 1,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header Row
              Container(
                decoration: const BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(6)),
                ),
                padding: const EdgeInsets.all(6),
                child: Row(
                  children: [
                    const Icon(Icons.home, color: AppColors.primary, size: 16),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        (data['hhId'] != null && data['hhId'].toString().length > 11)
                            ? data['hhId'].toString().substring(data['hhId'].toString().length - 11)
                            : (data['hhId']?.toString() ?? ''),
                        style: TextStyle(
                          color: primary,
                          fontWeight: FontWeight.w600,
                          fontSize: 14.sp,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Image.asset(
                      'assets/images/sync.png',
                      width: 25,
                      color: (data['is_synced'] ?? 0) == 1
                          ? Colors.green
                          : Colors.grey[500],
                    ),
                  
                  ],
                ),
              ),

              Container(
                decoration: BoxDecoration(
                  color: primary.withOpacity(0.95),
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(6)),
                ),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildRow([
                      _rowText('Registration Date', data['RegitrationDate'] ?? 'N/A'),
                      _rowText('Registration Type', data['RegitrationType'] ?? 'N/A'),
                      _rowText('Beneficiary ID',
                          (data['BeneficiaryID']?.toString().length ?? 0) > 11
                              ? data['BeneficiaryID'].toString().substring(data['BeneficiaryID'].toString().length - 11)
                              : (data['BeneficiaryID']?.toString() ?? 'N/A')
                      ),
                    ]),
                    const SizedBox(height: 8),
                    _buildRow([
                      _rowText('Name', data['Name'] ?? 'N/A'),
                      _rowText('Age | Gender', data['Age|Gender'] ?? 'N/A'),
                      _rowText('RCH ID', data['RchID'] ?? 'N/A'),
                    ]),
                    const SizedBox(height: 8),
                    _buildRow([
                      _rowText('Father Name', data['FatherName'] ?? 'N/A'),
                      _rowText('Mobile No.', data['Mobileno.'] ?? 'N/A'),
                      _rowText('Date of Death', data['DateofDeath'] ?? 'N/A'),
                    ]),
                    const SizedBox(height: 8),
                    _buildRow([
                      _rowText('Cause of Death', data['causeOFDeath'] ?? 'Not specified'),
                      _rowText('Reason', data['reason'] ?? 'Not specified'),
                      _rowText('Place', data['place'] ?? 'Not specified'),
                    ]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRow(List<Widget> children) {
    return Row(
      children: [
        for (int i = 0; i < children.length; i++) ...[
          Expanded(child: children[i]),
          if (i < children.length - 1) const SizedBox(width: 10),
        ]
      ],
    );
  }

  Widget _rowText(String title, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: AppColors.background,
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: AppColors.background,
            fontWeight: FontWeight.w400,
            fontSize: 13.sp,
          ),
        ),
      ],
    );
  }

  void _viewDetails(Map<String, dynamic> item) {
    final l10n = AppLocalizations.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n?.deceasedChildDetails ?? 'Deceased Child Details'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _detailRow('Name', item['Name']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('HH ID', item['hhId']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('Beneficiary ID', item['BeneficiaryID']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('Age | Gender', item['Age|Gender']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('Mobile', item['Mobileno.']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('Father\'s Name', item['FatherName']?.toString() ?? 'N/A'),
              const SizedBox(height: 16),
              Text(
                l10n?.deathDetailsLabel ?? 'Death Details',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const Divider(),
              const SizedBox(height: 8),
              _detailRow('Date of Death', item['DateofDeath']?.toString() ?? 'N/A'),
              const SizedBox(height: 8),
              _detailRow('Cause of Death', item['causeOFDeath']?.toString() ?? 'Not specified'),
              const SizedBox(height: 8),
              _detailRow('Place of Death', item['place']?.toString() ?? 'Not specified'),
              const SizedBox(height: 8),
              _detailRow('Reason', item['reason']?.toString() ?? 'Not specified'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n?.closeLabel ?? 'Close'),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(String title, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.w400,
            fontSize: 13,
          ),
        ),
      ],
    );
  }


}