part of 'training_received_bloc.dart';

@immutable
sealed class TrainingReceivedState {}

final class TrainingReceivedInitial extends TrainingReceivedState {}
