import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:medixcel_new/core/widgets/AppDrawer/Drawer.dart';
import 'package:medixcel_new/core/widgets/AppHeader/AppHeader.dart';
import 'package:medixcel_new/l10n/app_localizations.dart';
import 'package:medixcel_new/core/config/themes/CustomColors.dart';
import 'package:medixcel_new/presentation/Incentive_portal/Finalize_Incentive.dart';
import 'package:medixcel_new/presentation/Incentive_portal/Monthly_Task.dart';
import 'package:sizer/sizer.dart';

import '../../core/config/routes/Route_Name.dart';
import '../../core/widgets/MarqeeText/MarqeeText.dart';
import '../HomeScreen/HomeScreen.dart';
import 'IncentiveForm.dart';
import '../../data/Database/local_storage_dao.dart';

class IncentivePortal extends StatefulWidget {
  const IncentivePortal({super.key});

  @override
  State<IncentivePortal> createState() => _IncentivePortalState();
}

String _safeText(dynamic v) => v?.toString().trim().isNotEmpty == true ? v.toString() : '-';

extension on _IncentivePortalState {
  String _buildFullName() {
    if (_userData == null || _userData!.isEmpty) return '-';
    try {
      final details = _userData!['details'] is String
          ? (jsonDecode(_userData!['details']) as Map<String, dynamic>)
          : (_userData!['details'] as Map<String, dynamic>? ?? const {});
      final name = details['data']?['name'] ?? details['name'] ?? {};
      final first = _safeText(name['first_name']);
      final middle = _safeText(name['middle_name']);
      final last = _safeText(name['last_name']);
      final parts = [first, middle, last].where((p) => p != '-' && p.isNotEmpty).toList();
      return parts.isEmpty ? '-' : parts.join(' ');
    } catch (_) {
      return '-';
    }
  }

  String _getWorkingField(String key) {
    if (_userData == null || _userData!.isEmpty) return '-';
    try {
      final details = _userData!['details'] is String
          ? (jsonDecode(_userData!['details']) as Map<String, dynamic>)
          : (_userData!['details'] as Map<String, dynamic>? ?? const {});
      final working = details['data']?['working_location'] ?? details['working_location'] ?? {};
      return _safeText(working[key]);
    } catch (_) {
      return '-';
    }
  }
}

class _IncentivePortalState extends State<IncentivePortal>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _navigatingFinalize = false;

  final List<String> _years = [
    '2022-2023',
    '2023-2024',
    '2024-2025',
    '2025-2026',
  ];

  late String _selectedYear;
  late String _selectedMonth;
  bool _isFirstBuild = true;

  Map<String, dynamic>? _userData;
  bool _isUserLoading = true;

  Future<void> _loadUserData() async {
    try {
      final data = await LocalStorageDao.instance.getCurrentUserFromDb();
      if (!mounted) return;
      setState(() {
        _userData = data;
        _isUserLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isUserLoading = false;
      });
    }
  }

  List<String> _getMonthNames(AppLocalizations? l10n) => [
    l10n?.monthJanuary ?? 'January',
    l10n?.monthFebruary ?? 'February',
    l10n?.monthMarch ?? 'March',
    l10n?.monthApril ?? 'April',
    l10n?.monthMay ?? 'May',
    l10n?.monthJune ?? 'June',
    l10n?.monthJuly ?? 'July',
    l10n?.monthAugust ?? 'August',
    l10n?.monthSeptember ?? 'September',
    l10n?.monthOctober ?? 'October',
    l10n?.monthNovember ?? 'November',
    l10n?.monthDecember ?? 'December',
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _selectedYear = _years[2]; // default sample like screenshot
    _loadUserData();

    _tabController.addListener(() async {
      if (_navigatingFinalize) return;
      if (_tabController.index == 2 && !_tabController.indexIsChanging) {
        _navigatingFinalize = true;
        final prev = _tabController.previousIndex;
        // Revert selection back to previous tab to keep TabBarView here
        if (mounted) {
          setState(() {
            _tabController.index = prev;
          });
        }
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const FinalizeIncentivePage()),
        );
        _navigatingFinalize = false;
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final monthNames = _getMonthNames(l10n);
    
    if (_isFirstBuild) {
      _isFirstBuild = false;
      _selectedMonth = monthNames[DateTime.now().month - 1];
    } else if (_selectedMonth == null) {

    }

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppHeader(
        screenTitle: l10n?.drawerIncentivePortal ?? 'Incentive Portal',
        showBack: false,
        icon1Image: 'assets/images/google-docs.png',
        onIcon1Tap: () => Navigator.pushNamed(context, Route_Names.NationalProgramsScreen ),
        icon2Image: 'assets/images/home.png',
        onIcon2Tap: () => Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => HomeScreen(initialTabIndex: 1),
          ),
        ),
      ),
      drawer: CustomDrawer(),
      floatingActionButton: RawMaterialButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const IncentiveForm()),
          );
        },
        fillColor: AppColors.primary, // background color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(50),
        ),
        constraints: const BoxConstraints(
          minWidth: 50,
          minHeight: 50,
        ),
        child: Icon(Icons.add, color: AppColors.onPrimary),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              color: Colors.blue[50],
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _buildFullName(),
                      style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Divider(height: 1, color: AppColors.divider),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _InfoCell(title: l10n?.incentiveHeaderDistrict ?? 'District', value: _getWorkingField('district')),
                        _InfoCell(title: l10n?.incentiveHeaderBlock ?? 'Block', value: _getWorkingField('block')),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _InfoCell(title: l10n?.incentiveHeaderHsc ?? 'HSC', value: _getWorkingField('hsc_name')),
                        _InfoCell(title: l10n?.incentiveHeaderPanchayat ?? 'Panchayat', value: _getWorkingField('panchayat')),
                        _InfoCell(title: l10n?.incentiveHeaderAnganwadi ?? 'Anganwadi', value: _getWorkingField('anganwadi')),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),
            MarqueeText(
              text:  l10n?.incentiveNote ?? 'Submit monthly incentive claim files between 28th and 30th of next month.',
              style: TextStyle(color: AppColors.error, fontSize: 12),
              velocity: 50, // adjust speed
            ),


            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _LabeledDropdown<String>(
                    label: l10n?.incentiveFinancialYear ?? 'Financial year',
                    value: _selectedYear,
                    items: _years.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => _selectedYear = v ?? _selectedYear),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _LabeledDropdown<String>(
                    label:  l10n?.incentiveFinancialMonth ?? 'Financial month',
                    value: _selectedMonth,
                    items: monthNames.map((month) {
                      return DropdownMenuItem<String>(
                        value: month,
                        child: Text(month),
                      );
                    }).toList(),
                    onChanged: (v) => setState(() => _selectedMonth = v ?? _selectedMonth),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(6),
              ),
              child: Center(
                child: Text(
                  (l10n?.incentiveTotalAmount('0') ?? 'Total amount (daily + monthly): ₹0'),
                  style:  TextStyle(fontWeight: FontWeight.w600, fontSize: 15.sp),
                ),
              ),
            ),

            const SizedBox(height: 8),

            Container(
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: AppColors.divider, width: 1)),
                color: AppColors.surfaceVariant
              ),
              child: TabBar(
                controller: _tabController,
                labelColor: AppColors.primary,
                unselectedLabelColor: AppColors.onSurfaceVariant,
                indicatorColor: AppColors.primary,
                tabs: [
                  Tab(text:  l10n?.incentiveTabDaily ?? 'Daily tasks'),
                  Tab(text:  l10n?.incentiveTabMonthly ?? 'Monthly tasks'),
                  Tab(text: l10n?.incentiveTabFinalize ?? 'Finalize'),
                ],
              ),
            ),

            SizedBox(
              height: 300,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _SectionPlaceholder(
                    title: l10n?.incentiveDailyTabPlaceholder ?? 'Daily tasks content here',
                  ),
                  const MonthlyTasks(),
                  // Placeholder for the "Finalize" tab. The actual navigation to
                  // the FinalizeIncentivePage is handled via the TabController
                  // listener in initState, so this child is rarely shown but is
                  // required to keep the TabController length (3) in sync with
                  // the number of TabBarView children.
                  const SizedBox.shrink(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCell extends StatelessWidget {
  final String title;
  final String value;
  const _InfoCell({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(right: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(fontSize: 14.sp, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 2),
            Text(value, style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600, color: Theme.of(context).colorScheme.onSurface)),
          ],
        ),
      ),
    );
  }
}

class _LabeledDropdown<T> extends StatelessWidget {
  final String label;
  final T value;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?> onChanged;
  const _LabeledDropdown({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 14.sp, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        const SizedBox(height: 2),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
            borderRadius: BorderRadius.circular(6),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<T>(
              value: value,
              isExpanded: true,
              items: items,
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }
}
class _SectionPlaceholder extends StatelessWidget {
  final String title;
  const _SectionPlaceholder({required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 14.sp)),
    );
  }
}
